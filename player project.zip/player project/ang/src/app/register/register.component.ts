import { Component, OnInit } from '@angular/core';
import { Register } from '../models/registermodel';
import { Router } from '../../../node_modules/@angular/router';
import { PlayerService } from '../services/playerservice';



@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
reg:Register
constructor(private rt:Router ,private ps:PlayerService){
  this.reg=new Register();
}
  funsubmit(regForm){
if(regForm.valid){
  this.ps.register(this.reg).subscribe((data)=>{
    this.rt.navigate(['login'])
  })
}
}
  ngOnInit() {
  }

}
