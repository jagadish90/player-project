export class Register{
    userid:number;
    name:string;
    password:string

}