var fs = require('fs')
var path = require('path')
var bodyparser = require('body-parser')
var express = require('express')
var promise = require('bluebird')

var app = express();
var options = { promiseLib: promise }

var pgp = require('pg-promise')(options)

var cs = 'postgres://postgres:root@localhost:5432/player'


var db = pgp(cs)

app.set('port', process.env.PORT || 4600)



app.use(bodyparser.json({ limit: "50mb" }));
app.use(bodyparser.urlencoded({ limit: "50mb", extended: true, parameterLimit: 50000 }));

app.use(function (req, res, next) {

    res.setHeader('Access-Control-Allow-Origin', '*');


    res.setHeader('Access-Control-Allow-Methods', '*');


    res.setHeader('Access-Control-Allow-Headers', '*');


    res.setHeader('Access-Control-Allow-Credentials', true);


    next();
});


app.use(express.static(path.join(__dirname, 'images')))
app.get('/', (req, res) => {
    res.send('Database coinnectivity Ex.....')
})
app.get('/player', (req,res, next)=>{
db.any('select * from player').then(
    (data)=>{
        res.send(data)
    })
})

app.get('/player/:id',(req,res,next)=>{
 pid = req.params.id
db.any('select * from player where id = $1', pid).then(
(data)=>{
    res.send(data)
})
})




app.get('/register/:userid/:pwd', (req, res, next) => {
    var ui = req.params.userid

    var p = req.params.pwd
    console.log(ui + " " + p);
    db.any('select * from register where userid=$1 and password=$2', [ui, p])
        .then((data) => {
            res.send(data)
        })

})

app.post('/register', (req, res, next) => {
    var ui = parseInt(req.body.userid)
    var n = req.body.name
    var p = req.body.password
    db.any('insert into register values($1,$2,$3)', [ui, n, p]).then(
        (data) => {
            res.send({ 'message': 'saved success...' })
        }
    )

})



app.delete('/player/:id',(req,res,next)=>{
    var pid = req.params.id
    db.any('delete from player where id = $1', pid). then(
        (data)=>{
            res.send({'message':'Record Deleted Successsssss'})
        }
    )
})


app.post('/player',(req,res, next)=>{
    var fileName=req.body.id+'.png'
    var cfn=path.join(__dirname,'images/'+fileName)
    fs.writeFile(cfn,req.body.image,'base64',(err)=>{
        if(err)
            console.log('unable to save image')
            else
            console.log('image saved success')

    })
var i = parseInt(req.body.id)
var n = req.body.name 
var im ="http://localhost:4600/" +req.body.id+'.png'
var c = req.body.country
var tr =parseInt( req.body.totruns)
var tw = parseInt(req.body.totwickets)
db.any('insert into player values($1,$2,$3,$4,$5,$6)',[i,n,im,c,tr,tw]).then(
    (data)=>{
        res.send({'message' : 'Saved Successssssss...'})
    }
)
})

// app.post('/player',(req,res, next)=>{
// var i = parseInt(req.body.id)
// var n = req.body.name 
// var im = req.body.image
// var c = req.body.country
// var tr =parseInt( req.body.totruns)
// var tw = parseInt(req.body.totwickets)
// db.any('select fn_AddPlayer($1,$2,$3,$4,$5,$6)',[i,n,im,c,tr,tw]).then(
//     (data)=>{
//         res.send({'message' : 'Saved Successssssss...'})
//     }
// )
// })


app.put('/player',(req,res, next)=>{
    var fileName=req.body.id+'.png'
    var cfn=path.join(__dirname,'images/'+fileName)
    fs.writeFile(cfn,req.body.image,'base64',(err)=>{
        if(err)
            console.log('unable to update image')
            else
            console.log('image updated success')

    })

    var i = parseInt(req.body.id)
    var n = req.body.name 
    var im ="http://localhost:4600/" +req.body.id+'.png'
    var c = req.body.country
    var tr =parseInt( req.body.totruns)
    var tw = parseInt(req.body.totwickets)
db.any(
    `update player 
    set name= $1, 
    image= $2, 
    country = $3 , 
    totruns = $4 , 
    totwickets = $5 
    where id = $6 `,[n,im, c,tr, tw, i]). then(
    (data)=>{
        res.send({'message':'Updated Sucesssss....'})
    }
)
})




app.listen(app.get('port'), (err) => {
    if (err)
        console.log('server not strated ...')
    else
        console.log('server Started at  : http://localhost:4600')
})
